package bitc.full502.spring.web;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api/naver/local")
public class NaverLocalProxyController {

    // application.yml 등에 보관 권장 (임시로 @Value)
    @Value("${naver.client-id:h81w25c1vt}")
    private String clientId;

    @Value("${naver.client-secret:YyrMEF0cybeLNyOqYdrFskiboAs45VqjsR1Nzv6D}")
    private String clientSecret;

    private final RestTemplate rt = new RestTemplate();

    /**
     * 네이버 지역검색 프록시
     * - 네이버 오픈API: https://openapi.naver.com/v1/search/local.json
     * - 파라미터: query(필수), display/start/sort 등
     * - 여기서는 query만 받아 size(표시 수)를 가변으로 지원
     */
    @GetMapping("/nearby")
    public Map<String, Object> nearby(
            @RequestParam String query,
            @RequestParam double lat,
            @RequestParam double lon,
            @RequestParam(defaultValue = "1000") int radius,
            @RequestParam(defaultValue = "30") int size
    ) {
        try {
            // 지역검색은 반경 파라미터가 없어 "맛집" 결과를 충분히 받도록 size만 늘림(최대 30 권장)
            String url = "https://openapi.naver.com/v1/search/local.json"
                    + "?query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&display=" + size
                    + "&start=1"
                    + "&sort=random"; // 정확도순

            HttpHeaders headers = new HttpHeaders();
            headers.set("X-Naver-Client-Id", clientId);
            headers.set("X-Naver-Client-Secret", clientSecret);

            ResponseEntity<Map> resp = rt.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), Map.class);
            // 그대로 반환: { items: [...], total:..., ... }
            return resp.getBody();
        } catch (Exception e) {
            return Map.of("items", java.util.List.of(), "error", e.getMessage());
        }
    }
}

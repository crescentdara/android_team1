package bitc.fullstack502.android_studio.network.dto

data class LodgingWishStatusDto(
    val wished: Boolean,
    val wishCount: Long
)

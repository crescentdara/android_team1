package bitc.fullstack502.android_studio.ui.lodging

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import bitc.fullstack502.android_studio.R

class TempPaymentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = """
                [결제화면(임시)]
                lodgingId=${intent.getLongExtra("lodgingId", 0)}
                name=${intent.getStringExtra("lodgingName")}
                type=${intent.getStringExtra("roomType")}
                price=${intent.getIntExtra("price", 0)}
                checkIn=${intent.getStringExtra("checkIn")}
                checkOut=${intent.getStringExtra("checkOut")}
            """.trimIndent()
            textSize = 16f
            setPadding(32, 64, 32, 64)
        }
        setContentView(tv)
    }
}

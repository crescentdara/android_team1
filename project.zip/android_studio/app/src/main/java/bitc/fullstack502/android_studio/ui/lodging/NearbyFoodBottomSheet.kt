package bitc.fullstack502.android_studio.ui.lodging

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import bitc.fullstack502.android_studio.R
import bitc.fullstack502.android_studio.network.RetrofitProvider
import bitc.fullstack502.android_studio.network.dto.NaverLocalApi
import bitc.fullstack502.android_studio.network.dto.NaverLocalResp
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NearbyFoodBottomSheet : BottomSheetDialogFragment() {

    private var lat = 0.0
    private var lon = 0.0
    private var title = "숙소"

    private lateinit var webNearby: WebView
    private var pageLoaded = false
    private var queuedPlacesJson: String? = null

    private val api by lazy { RetrofitProvider.retrofit.create(NaverLocalApi::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            lat = it.getDouble("lat")
            lon = it.getDouble("lon")
            title = it.getString("title") ?: "숙소"
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.bottomsheet_nearby_food, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        webNearby = view.findViewById(R.id.webNearby)
        webNearby.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webNearby.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
                queuedPlacesJson?.let {
                    webNearby.evaluateJavascript("window.addPlacesTM128($it);", null)
                    queuedPlacesJson = null
                }
            }
        }

        // 1) 지도 HTML 먼저 로드
        val url = Uri.parse("file:///android_asset/nearby_map.html")
            .buildUpon()
            .appendQueryParameter("lat", lat.toString())
            .appendQueryParameter("lon", lon.toString())
            .appendQueryParameter("title", title)
            .build().toString()
        webNearby.loadUrl(url)

        // 2) 서버 프록시로 맛집 가져온 후 JS 함수 호출
        api.nearby("맛집", lat, lon, 1000, 30)
            .enqueue(object : Callback<NaverLocalResp> {
                override fun onResponse(call: Call<NaverLocalResp>, response: Response<NaverLocalResp>) {
                    val list = response.body()?.items?.map {
                        mapOf(
                            "title" to (it.title ?: ""),
                            "mapx" to (it.mapx ?: ""),
                            "mapy" to (it.mapy ?: "")
                        )
                    } ?: emptyList()

                    val json = org.json.JSONArray(list).toString()
                    if (pageLoaded) {
                        webNearby.evaluateJavascript("window.addPlacesTM128($json);", null)
                    } else {
                        queuedPlacesJson = json
                    }
                }

                override fun onFailure(call: Call<NaverLocalResp>, t: Throwable) {
                    // 필요 시 토스트/로그
                }
            })
    }

    override fun onDestroyView() {
        webNearby.destroy()
        super.onDestroyView()
    }

    companion object {
        fun newInstance(lat: Double, lon: Double, title: String) = NearbyFoodBottomSheet().apply {
            arguments = Bundle().apply {
                putDouble("lat", lat)
                putDouble("lon", lon)
                putString("title", title)
            }
        }
    }
}

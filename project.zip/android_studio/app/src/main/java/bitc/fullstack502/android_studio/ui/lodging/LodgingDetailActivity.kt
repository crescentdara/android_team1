package bitc.fullstack502.android_studio.ui.lodging

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import bitc.fullstack502.android_studio.R
import bitc.fullstack502.android_studio.network.LodgingDetailApi
import bitc.fullstack502.android_studio.network.LodgingWishApi
import bitc.fullstack502.android_studio.network.RetrofitProvider
import bitc.fullstack502.android_studio.network.dto.AvailabilityDto
import bitc.fullstack502.android_studio.network.dto.LodgingDetailDto
import bitc.fullstack502.android_studio.network.dto.LodgingWishStatusDto
import com.bumptech.glide.Glide
import com.google.android.material.datepicker.MaterialDatePicker
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class LodgingDetailActivity : AppCompatActivity() {

    private lateinit var api: LodgingDetailApi
    private lateinit var wishApi: LodgingWishApi

    private lateinit var webMap: WebView

    private var lodgingId: Long = 0L
    private var lat = 0.0
    private var lon = 0.0
    private var name = ""

    private lateinit var imgCover: ImageView
    private lateinit var tvName: TextView
    private lateinit var tvAddr: TextView
    private lateinit var tvPhone: TextView
    private lateinit var etIn: EditText
    private lateinit var etOut: EditText
    private lateinit var rgRoom: RadioGroup
    private lateinit var rbSingle: RadioButton
    private lateinit var rbDeluxe: RadioButton
    private lateinit var rbSuite: RadioButton
    private lateinit var tvSelection: TextView
    private lateinit var btnNearby: Button
    private lateinit var btnReserve: Button

    // wish
    private lateinit var btnWish: ImageButton
    private lateinit var tvWishCount: TextView
    private var wished = false
    private val testUserId = 1L

    private val priceWon = 100_000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lodging_detail)

        // WebView
        webMap = findViewById(R.id.webMap)
        webMap.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        WebView.setWebContentsDebuggingEnabled(true)
        webMap.webViewClient = WebViewClient()

        // Views
        imgCover = findViewById(R.id.imgCover)
        tvName = findViewById(R.id.tvName)
        tvAddr = findViewById(R.id.tvAddr)
        tvPhone = findViewById(R.id.tvPhone)
        etIn = findViewById(R.id.etCheckIn)
        etOut = findViewById(R.id.etCheckOut)
        rgRoom = findViewById(R.id.rgRoom)
        rbSingle = findViewById(R.id.rbSingle)
        rbDeluxe = findViewById(R.id.rbDeluxe)
        rbSuite = findViewById(R.id.rbSuite)
        tvSelection = findViewById(R.id.tvSelection)
        btnNearby = findViewById(R.id.btnNearby)
        btnReserve = findViewById(R.id.btnReserve)

        btnWish = findViewById(R.id.btnWish)
        tvWishCount = findViewById(R.id.tvWishCount)

        // APIs
        api = RetrofitProvider.retrofit.create(LodgingDetailApi::class.java)
        wishApi = RetrofitProvider.retrofit.create(LodgingWishApi::class.java)

        // 리스트에서 못 받으면 테스트로 id=1 강제
        lodgingId = intent.getLongExtra("lodgingId", 0L).let { if (it == 0L) 1L else it }

        // 예약 버튼: 최초 비활성
        setReserveEnabled(false)

        fetchDetail()

        // 날짜는 한 번에 기간 선택
        etIn.setOnClickListener { showDateRangePicker() }
        etOut.setOnClickListener { showDateRangePicker() }
        rgRoom.setOnCheckedChangeListener { _, _ -> updateSelection() }

        btnNearby.setOnClickListener {
            NearbyFoodBottomSheet.newInstance(lat, lon, name.ifBlank { "숙소" })
                .show(supportFragmentManager, "nearby_food")
        }

        btnReserve.setOnClickListener {
            // 날짜 가드
            if (etIn.text.isNullOrBlank() || etOut.text.isNullOrBlank()) {
                Toast.makeText(this, "체크인/체크아웃 날짜를 먼저 선택하세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (rgRoom.checkedRadioButtonId == -1) {
                Toast.makeText(this, "객실 타입을 선택하세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val roomType = when (rgRoom.checkedRadioButtonId) {
                R.id.rbSingle -> "SINGLE"
                R.id.rbDeluxe -> "DELUXE"
                else -> "SUITE"
            }
            startActivity(Intent(this, TempPaymentActivity::class.java).apply {
                putExtra("lodgingId", lodgingId)
                putExtra("lodgingName", name)
                putExtra("roomType", roomType)
                putExtra("price", priceWon)
                putExtra("checkIn", etIn.text.toString())
                putExtra("checkOut", etOut.text.toString())
            })
        }

        btnWish.setOnClickListener { toggleWish() }
    }

    private fun fetchDetail() {
        api.getDetail(lodgingId).enqueue(object : Callback<LodgingDetailDto> {
            override fun onResponse(c: Call<LodgingDetailDto>, r: Response<LodgingDetailDto>) {
                if (!r.isSuccessful) {
                    Log.e("Detail", "HTTP ${r.code()} ${r.errorBody()?.string()}")
                    Toast.makeText(this@LodgingDetailActivity, "상세 호출 실패(${r.code()})", Toast.LENGTH_SHORT).show()
                    return
                }
                val d = r.body() ?: run {
                    Toast.makeText(this@LodgingDetailActivity, "상세 없음(id=$lodgingId)", Toast.LENGTH_SHORT).show()
                    return
                }

                name = d.name.orEmpty()
                lat = d.lat ?: 0.0
                lon = d.lon ?: 0.0
                if (lat == 0.0 && lon == 0.0) { lat = 37.5666102; lon = 126.9783881 } // 임시 좌표

                tvName.text = name
                tvAddr.text = listOfNotNull(d.addrRd, d.addrJb).joinToString(" / ")
                tvPhone.text = d.phone ?: ""
                if (!d.img.isNullOrBlank()) Glide.with(this@LodgingDetailActivity).load(d.img).into(imgCover)

                val url = Uri.parse("file:///android_asset/naver_map.html")
                    .buildUpon()
                    .appendQueryParameter("lat", lat.toString())
                    .appendQueryParameter("lon", lon.toString())
                    .appendQueryParameter("title", name.ifBlank { "숙소" })
                    .build().toString()
                webMap.loadUrl(url)

                // 위시 상태 로드
                refreshWish()
            }

            override fun onFailure(c: Call<LodgingDetailDto>, t: Throwable) {
                Log.e("Detail", "API 실패", t)
                Toast.makeText(this@LodgingDetailActivity, "상세 불러오기 실패", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun refreshWish() {
        wishApi.status(lodgingId, testUserId).enqueue(object : Callback<LodgingWishStatusDto> {
            override fun onResponse(call: Call<LodgingWishStatusDto>, response: Response<LodgingWishStatusDto>) {
                response.body()?.let { s ->
                    wished = s.wished
                    tvWishCount.text = s.wishCount.toString()
                    updateWishIcon()
                }
            }
            override fun onFailure(call: Call<LodgingWishStatusDto>, t: Throwable) { }
        })
    }

    private fun toggleWish() {
        wishApi.toggle(lodgingId, testUserId).enqueue(object : Callback<LodgingWishStatusDto> {
            override fun onResponse(call: Call<LodgingWishStatusDto>, response: Response<LodgingWishStatusDto>) {
                response.body()?.let { s ->
                    wished = s.wished
                    tvWishCount.text = s.wishCount.toString()
                    updateWishIcon()
                }
            }
            override fun onFailure(call: Call<LodgingWishStatusDto>, t: Throwable) { }
        })
    }

    private fun updateWishIcon() {
        btnWish.setImageResource(if (wished) R.drawable.ic_star_24 else R.drawable.ic_star_border_24)
    }

    /** 기간 선택 (한 번에) + n박 표시 + 가용조회 + 예약버튼 활성화 */
    private fun showDateRangePicker() {
        val picker = MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText("숙박 기간 선택")
            .build()

        picker.addOnPositiveButtonClickListener { sel ->
            val start = sel.first
            val end = sel.second
            if (start != null && end != null) {
                val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
                val ci = fmt.format(Date(start))
                val co = fmt.format(Date(end))
                etIn.setText(ci)
                etOut.setText(co)

                val nights = ((end - start) / (24 * 60 * 60 * 1000)).toInt()
                val room = when (rgRoom.checkedRadioButtonId) {
                    R.id.rbSingle -> "싱글"
                    R.id.rbDeluxe -> "디럭스"
                    R.id.rbSuite -> "스위트"
                    else -> "-"
                }
                val priceText = if (room == "-") "" else " / 가격: ₩%,d".format(priceWon)
                tvSelection.text = "선택한 옵션: $room$priceText • ${nights}박"

                updateReserveEnabled()
                checkAvailability(ci, co)
            }
        }
        picker.show(supportFragmentManager, "date_range")
    }

    private fun checkAvailability(ci: String, co: String) {
        api.getAvailability(lodgingId, ci, co, null).enqueue(object : Callback<AvailabilityDto> {
            override fun onResponse(c: Call<AvailabilityDto>, r: Response<AvailabilityDto>) {
                val a = r.body() ?: return
                val enable = a.availableRooms > 0
                rbSingle.isEnabled = enable
                rbDeluxe.isEnabled = enable
                rbSuite.isEnabled = enable
                if (!enable) {
                    rgRoom.clearCheck()
                    tvSelection.text = "선택한 옵션: (만실)"
                    Toast.makeText(this@LodgingDetailActivity, a.reason ?: "만실", Toast.LENGTH_SHORT).show()
                } else updateSelection()
            }
            override fun onFailure(c: Call<AvailabilityDto>, t: Throwable) {
                Toast.makeText(this@LodgingDetailActivity, "가용 조회 실패", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateSelection() {
        val room = when (rgRoom.checkedRadioButtonId) {
            R.id.rbSingle -> "싱글"
            R.id.rbDeluxe -> "디럭스"
            R.id.rbSuite -> "스위트"
            else -> "-"
        }
        val priceText = if (room == "-") "" else " / 가격: ₩%,d".format(priceWon)
        val current = tvSelection.text.toString()
        val nightsSuffix = current.substringAfter("•", missingDelimiterValue = "").trim()
        tvSelection.text = "선택한 옵션: $room$priceText" + (if (nightsSuffix.isNotEmpty()) " • $nightsSuffix" else "")
    }

    private fun setReserveEnabled(enabled: Boolean) {
        btnReserve.isEnabled = enabled
        btnReserve.alpha = if (enabled) 1f else 0.5f
    }
    private fun updateReserveEnabled() {
        val ok = etIn.text?.length == 10 && etOut.text?.length == 10
        setReserveEnabled(ok)
    }

    override fun onDestroy() {
        webMap.destroy()
        super.onDestroy()
    }
}
